#!/bin/bash

apt-get install curl php5-cli php5-curl
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer