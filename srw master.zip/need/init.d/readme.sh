#!/bin/bash
mkdir /var/run/gearman
ln -s $PWD/gearman-job-server /etc/init.d/
update-rc.d gearman-job-server defaults
useradd gearman
chown gearman:gearman /var/run/gearman/