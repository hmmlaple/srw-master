<?php

// with "need" have high priority
return [
    'clientarea.php' => [
        'need' => ['email\saddress', 'password', 'vps', 'cloud', 'domains'],
        'pre' => ['customers']
    ],
    'login.htm' => [
        'need' => ['hosting']
    ],
    'web-hosting/cplogin' => [],
    'hosting/webmail' => [],
];